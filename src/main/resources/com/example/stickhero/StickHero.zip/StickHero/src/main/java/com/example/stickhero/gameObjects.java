package com.example.stickhero;

public interface gameObjects {
    void setPosition(coordinates cherryPosition);
    coordinates getPosition();
}
