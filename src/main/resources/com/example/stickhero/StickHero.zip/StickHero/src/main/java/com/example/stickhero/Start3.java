package com.example.stickhero;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Start3 extends Application {
    private static Pane scenePane;
    private Stage myStage;

    private Text cherryText;



    @Override
    public void start(Stage stage) throws Exception {
        System.out.println("-----STARTING--------");
        Parent root = FXMLLoader.load(getClass().getResource("store.fxml"));
        scenePane = new Pane(root);
        Scene scene = new Scene(scenePane);
        stage.setScene(scene);
        myStage = stage;
        cherryText = new Text();
        cherryText.setText(String.valueOf(11));
        cherryText.setLayoutX(338);
        cherryText.setLayoutY(42);
        cherryText.setFill(Color.WHITE);
        Font customFont = Font.loadFont(getClass().getResourceAsStream("/com/example/stickhero/ROGFonts-Regular.otf"), 24);
        int x = HelloApplication.getUserCredits();

        cherryText.setFont(customFont);
        cherryText.setText(String.valueOf(x));

        scenePane.getChildren().add(cherryText);
        stage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }
}
