//package com.example.stickhero;
//import kotlin.Result;
//import org.junit.*;
//import org.testng.annotations.Test;
//
//public class GameTester {
//
//    @Test
//    public void gameTest(){
//
//    }
//}
//
//
//class TestController{
//
//    public void main(){
//
//        Result result = JUnitCore.runClasses(Start2.class);
//
//    }
//}