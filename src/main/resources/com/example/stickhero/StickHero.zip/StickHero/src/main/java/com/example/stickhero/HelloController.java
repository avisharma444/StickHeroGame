package com.example.stickhero;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class HelloController {
    private Stage stage;
    private Scene scene;
    private Parent root;

    public Button front;
    public Button back;
    public Button load_game;
    public Button play;

    @FXML
    public Text uc;

    public void toHomeScreen(MouseEvent event) throws IOException, gameNotFoundError {
        Parent root = FXMLLoader.load(getClass().getResource("start_menu.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void toStart(ActionEvent event) throws IOException, gameNotFoundError {
        Parent root = FXMLLoader.load(getClass().getResource("start_menu.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void toLoadGame(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("loadGame.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public Text buttontext;


    public static int choice= 1;

    public void ChooseFinal(ActionEvent event) throws IOException {
        System.out.println(choice);
        switch (choice){
            case 1:
                toGameplay(event);
                break;
            case 2:
                toLoadGame(event);
                break;
        }
    }

    public void TextChanger(int choice){
        if(choice==2){
            buttontext.setText("Load game");
        }else if(choice==1){
            buttontext.setText("New game");
        }
    }

    public void ChooseActionForward(ActionEvent event) throws IOException {
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        if(choice!=2){
            choice++;
            TextChanger(choice);
            System.out.println("hiiii");
        }
    }

    @FXML
    public void ChooseActionBackward(ActionEvent event) throws IOException {
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        if (choice!=1){
            choice--;
            TextChanger(choice);
        }

    }
    @FXML
    public void initialize(){
        System.out.println("c i ");
    }
    public static Text creds = new Text();



    public void toGameplay(ActionEvent event) throws IOException {
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Start2 gcontroller = new Start2();
        gcontroller.start(stage);
    }

    public void toMarket(ActionEvent event) throws Exception {
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Start3 mcontroller = new Start3();
        try {
            mcontroller.start(stage);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void deserialize1(ActionEvent event) throws IOException, ClassNotFoundException {
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        String progressFile = "saveProgress.txt";
        ObjectInputStream in = null;
        try {
            in = new ObjectInputStream (
                    new FileInputStream(progressFile));
            saveDetails s1 = (saveDetails) in.readObject();

            Start2 p1 = new Start2();
            p1.setReloadFlag(1);
            p1.setSaveCurrState(s1);
            p1.start(stage);
        } finally {
            in.close();
        }
    }


    public void deserialize2(ActionEvent event) throws IOException, ClassNotFoundException {
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        String progressFile = "saveProgress2.txt";
        ObjectInputStream in = null;

        try {
            in = new ObjectInputStream (
                    new FileInputStream(progressFile));
            saveDetails s1 = (saveDetails) in.readObject();

            Start2 p1 = new Start2();
            p1.setReloadFlag(1);
            p1.setSaveCurrState(s1);
            p1.start(stage);
        } finally {
            in.close();
        }
    }
    public void deserialize3(ActionEvent event) throws IOException, ClassNotFoundException {
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        String progressFile = "saveProgress1.txt";
        ObjectInputStream in = null;
        try {
            in = new ObjectInputStream (
                    new FileInputStream(progressFile));
            saveDetails s1 = (saveDetails) in.readObject();

            Start2 p1 = new Start2();
            p1.setReloadFlag(1);
            p1.setSaveCurrState(s1);
            p1.start(stage);
        } finally {
            in.close();
        }
    }

    public void deserializeLast(ActionEvent event) throws IOException, ClassNotFoundException {
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        String progressFile = "saveProgressNew.txt";
        ObjectInputStream in = null;
        try {
            in = new ObjectInputStream (
                    new FileInputStream(progressFile));
            saveDetails s1 = (saveDetails) in.readObject();

            Start2 p1 = new Start2();
            p1.setReloadFlag(1);
            p1.setSaveCurrState(s1);
            p1.start(stage);
        } finally {
            in.close();
        }
    }
}

class setC implements Runnable{
    @Override
    public void run() {
        Platform.runLater(() -> {
            HelloController.creds.setText(String.valueOf(HelloApplication.getUserCreds()));
        });
    }
}
