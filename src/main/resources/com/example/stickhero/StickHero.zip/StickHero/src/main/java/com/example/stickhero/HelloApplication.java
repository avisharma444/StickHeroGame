package com.example.stickhero;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class HelloApplication extends Application {


    private static int userCreds;

    public static int getUserCreds() {
        return userCreds;
    }

    public static void setUserCreds(int userCreds) {
        HelloApplication.userCreds = userCreds;
    }

    public static Stage stage_primary;
    public static Parent root;

    static {
        try {
            root = FXMLLoader.load(HelloApplication.class.getResource("start_menu.fxml"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static FXMLLoader Over_menu;

    static {
        Over_menu = new FXMLLoader(HelloApplication.class.getResource("over_menu.fxml"));
    }
    public static Scene OverMenu;

    static {
        try {
            OverMenu = new Scene(Over_menu.load(),420,700);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }



    @Override
    public void start(Stage stage) {
        try {
            int credits = getUserCredits();
            setUserCreds(credits);
            System.out.println("user ccredits are - "+getUserCreds());

            stage_primary=stage;
            Scene scene = new Scene(root);
            stage_primary.setScene(scene);
            stage_primary.show();

        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    static int getUserCredits() throws FileNotFoundException {
        Scanner in2 = new Scanner(new BufferedInputStream(new FileInputStream("src/main/java/com/example/stickhero/credits")));
        ArrayList<Integer> int_arr2 = new ArrayList<>();
        while(in2.hasNext()){
            int y = Integer.parseInt(in2.next());
            int_arr2.add(y);
        }
        return int_arr2.get(0);
    }

    static void setUserCredits(int creds) throws IOException {
        PrintWriter fww2 = new PrintWriter((new FileWriter("src/main/java/com/example/stickhero/credits")));
        String s = String.valueOf(creds);
        fww2.write(s);
        fww2.close();
    }

}