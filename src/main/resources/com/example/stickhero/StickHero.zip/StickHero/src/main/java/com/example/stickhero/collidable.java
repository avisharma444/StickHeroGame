package com.example.stickhero;

public interface collidable {
}
